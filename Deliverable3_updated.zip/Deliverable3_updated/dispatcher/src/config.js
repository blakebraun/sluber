let config = {
    backendURL: 'http://localhost:4200'
};

module.exports = config;