This update contains the location tracking in the client. It was not pushed in time for the due date. Sorry about that!
