var config = {
    expressPort: 4200,
    mongoURL: 'mongodb://localhost:27017/sluber'
};

module.exports = config;